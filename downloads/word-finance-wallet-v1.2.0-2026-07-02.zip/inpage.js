(() => {
  // src/lib/wallet-standard.js
  var WF_ICON = "data:image/svg+xml;base64," + btoa(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128">
  <rect width="128" height="128" rx="24" fill="#9333ea"/>
  <text x="64" y="88" text-anchor="middle" fill="#fff" font-family="Arial,sans-serif" font-weight="bold" font-size="72">W</text>
</svg>
`.trim());
  function registerWalletStandard(solanaProxy) {
    function doRegister() {
      try {
        window.dispatchEvent(new CustomEvent("wallet-standard:register-wallet", {
          detail: {
            register: function(registerFn) {
              const wallet = {
                version: "1.0.0",
                name: "Word Finance",
                icon: WF_ICON,
                chains: ["solana:mainnet"],
                features: {
                  "standard:connect": {
                    version: "1.0.0",
                    connect: async function(input) {
                      const result = await solanaProxy.connect(input);
                      return {
                        accounts: [{
                          address: result.publicKey.toString(),
                          publicKey: result.publicKey.toBytes ? result.publicKey.toBytes() : base58ToBytes(result.publicKey.toString()),
                          chains: ["solana:mainnet"],
                          features: [
                            "solana:signTransaction",
                            "solana:signAndSendTransaction",
                            "solana:signMessage"
                          ]
                        }]
                      };
                    }
                  },
                  "standard:disconnect": {
                    version: "1.0.0",
                    disconnect: async function() {
                      await solanaProxy.disconnect();
                    }
                  },
                  "standard:events": {
                    version: "1.0.0",
                    on: function(event, listener) {
                      solanaProxy.on(event, listener);
                      return function() {
                        solanaProxy.off(event, listener);
                      };
                    }
                  },
                  "solana:signTransaction": {
                    version: "1.0.0",
                    supportedTransactionVersions: ["legacy", 0],
                    signTransaction: async function(inputs) {
                      const results = [];
                      for (const input of inputs) {
                        const signed = await solanaProxy.signTransaction(input.transaction);
                        results.push({ signedTransaction: signed });
                      }
                      return results;
                    }
                  },
                  "solana:signAndSendTransaction": {
                    version: "1.0.0",
                    supportedTransactionVersions: ["legacy", 0],
                    signAndSendTransaction: async function(inputs) {
                      const results = [];
                      for (const input of inputs) {
                        const result = await solanaProxy.signAndSendTransaction(input.transaction);
                        results.push({ signature: base58ToBytes(result.signature) });
                      }
                      return results;
                    }
                  },
                  "solana:signMessage": {
                    version: "1.0.0",
                    signMessage: async function(inputs) {
                      const results = [];
                      for (const input of inputs) {
                        const result = await solanaProxy.signMessage(input.message);
                        results.push({
                          signedMessage: input.message,
                          signature: result.signature
                        });
                      }
                      return results;
                    }
                  }
                },
                accounts: []
              };
              registerFn(wallet);
            }
          }
        }));
      } catch (e) {
      }
    }
    const delays = [0, 300, 800, 2e3];
    delays.forEach((ms) => setTimeout(doRegister, ms));
  }
  function base58ToBytes(b58str) {
    const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
    const BASE = 58;
    const bytes = [0];
    for (const char of b58str) {
      let carry = ALPHABET.indexOf(char);
      if (carry < 0) throw new Error("Invalid base58 char: " + char);
      for (let i = 0; i < bytes.length; i++) {
        carry += bytes[i] * BASE;
        bytes[i] = carry & 255;
        carry >>= 8;
      }
      while (carry > 0) {
        bytes.push(carry & 255);
        carry >>= 8;
      }
    }
    for (const char of b58str) {
      if (char !== "1") break;
      bytes.push(0);
    }
    return new Uint8Array(bytes.reverse());
  }

  // src/inpage.js
  (function() {
    "use strict";
    if (window.solana && !window.solana.isWordFinance) {
      window.__otherSolanaProvider = window.solana;
    }
    const callbacks = {};
    let callbackId = 0;
    const eventListeners = {};
    function nextId() {
      return "wf_" + ++callbackId + "_" + Date.now();
    }
    function sendRequest(type, data) {
      return new Promise((resolve, reject) => {
        const id = nextId();
        callbacks[id] = { resolve, reject };
        setTimeout(() => {
          if (callbacks[id]) {
            delete callbacks[id];
            reject(new Error("Word Finance: request timeout"));
          }
        }, 3e5);
        window.dispatchEvent(new CustomEvent("wf-extension-request", {
          detail: { id, type, data: data || {} }
        }));
      });
    }
    window.addEventListener("wf-extension-response", (e) => {
      const { id, result, error } = e.detail;
      const cb = callbacks[id];
      if (!cb) return;
      delete callbacks[id];
      if (error) {
        cb.reject(new Error(error));
      } else {
        cb.resolve(result);
      }
    });
    class WFPublicKey {
      constructor(b58) {
        this._b58 = b58;
      }
      toString() {
        return this._b58;
      }
      toBase58() {
        return this._b58;
      }
      toJSON() {
        return this._b58;
      }
      toBytes() {
        return base58Decode(this._b58);
      }
      equals(other) {
        if (!other) return false;
        return this._b58 === (other.toBase58 ? other.toBase58() : other.toString());
      }
    }
    let _publicKey = null;
    let _isConnected = false;
    const solanaProxy = {
      isWordFinance: true,
      isPhantom: false,
      // Não fingir ser Phantom
      name: "Word Finance",
      get publicKey() {
        return _publicKey;
      },
      get isConnected() {
        return _isConnected;
      },
      async connect(opts) {
        const result = await sendRequest("connect", opts || {});
        _publicKey = new WFPublicKey(result.publicKey);
        _isConnected = true;
        emitEvent("connect", { publicKey: _publicKey });
        return { publicKey: _publicKey };
      },
      async disconnect() {
        await sendRequest("disconnect", {});
        _publicKey = null;
        _isConnected = false;
        emitEvent("disconnect");
      },
      async signMessage(message) {
        let msgArray;
        if (message instanceof Uint8Array) {
          msgArray = Array.from(message);
        } else if (typeof message === "string") {
          msgArray = Array.from(new TextEncoder().encode(message));
        } else {
          msgArray = Array.from(message);
        }
        const result = await sendRequest("signMessage", { message: msgArray });
        return {
          signature: new Uint8Array(result.signature),
          publicKey: _publicKey
        };
      },
      async signTransaction(transaction) {
        let txBytes;
        if (transaction.serialize) {
          txBytes = Array.from(transaction.serialize({ requireAllSignatures: false }));
        } else if (transaction instanceof Uint8Array) {
          txBytes = Array.from(transaction);
        } else {
          txBytes = Array.from(transaction);
        }
        const result = await sendRequest("signTransaction", { transaction: txBytes });
        return new Uint8Array(result.signedTransaction);
      },
      async signAndSendTransaction(transaction, opts) {
        let txBytes;
        if (transaction.serialize) {
          txBytes = Array.from(transaction.serialize({ requireAllSignatures: false }));
        } else if (transaction instanceof Uint8Array) {
          txBytes = Array.from(transaction);
        } else {
          txBytes = Array.from(transaction);
        }
        const result = await sendRequest("signAndSendTransaction", {
          transaction: txBytes,
          options: opts || {}
        });
        return { signature: result.signature };
      },
      async signAllTransactions(transactions) {
        const results = [];
        for (const tx of transactions) {
          results.push(await this.signTransaction(tx));
        }
        return results;
      },
      on(event, callback) {
        if (!eventListeners[event]) eventListeners[event] = [];
        eventListeners[event].push(callback);
      },
      off(event, callback) {
        if (!eventListeners[event]) return;
        eventListeners[event] = eventListeners[event].filter((cb) => cb !== callback);
      },
      emit(event, data) {
        emitEvent(event, data);
      },
      request(args) {
        if (args.method === "connect") return this.connect(args.params);
        if (args.method === "disconnect") return this.disconnect();
        if (args.method === "signMessage") return this.signMessage(args.params.message);
        if (args.method === "signTransaction") return this.signTransaction(args.params.transaction);
        throw new Error("Word Finance: unsupported method " + args.method);
      }
    };
    function emitEvent(event, data) {
      const listeners = eventListeners[event];
      if (listeners) {
        listeners.forEach((cb) => {
          try {
            cb(data);
          } catch (e) {
            console.warn("WF event handler error:", e);
          }
        });
      }
    }
    (function installProvider() {
      try {
        if (window.solana && !window.solana.isWordFinance) {
          window.__otherSolanaProvider = window.solana;
        }
      } catch (e) {}
      var installed = false;
      try {
        var desc = Object.getOwnPropertyDescriptor(window, "solana");
        if (!desc || desc.configurable) {
          try { delete window.solana; } catch (ed) {}
          Object.defineProperty(window, "solana", {
            value: solanaProxy,
            writable: true,
            configurable: true
          });
          installed = true;
        }
      } catch (e) {}
      if (!installed) {
        try { window.solana = solanaProxy; installed = true; } catch (e2) {}
      }
      if (!installed) {
        console.warn("[Word Finance] window.solana ocupado por outra extensao. Use window.wordFinance");
      }
    })();
    window.wordFinance = solanaProxy;
    registerWalletStandard(solanaProxy);
    try {
      window.dispatchEvent(new Event("solana#initialized"));
    } catch (e) {
    }
    function base58Decode(b58) {
      const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
      const bytes = [0];
      for (const char of b58) {
        let carry = ALPHABET.indexOf(char);
        if (carry < 0) return new Uint8Array(0);
        for (let i = 0; i < bytes.length; i++) {
          carry += bytes[i] * 58;
          bytes[i] = carry & 255;
          carry >>= 8;
        }
        while (carry > 0) {
          bytes.push(carry & 255);
          carry >>= 8;
        }
      }
      for (const c of b58) {
        if (c !== "1") break;
        bytes.push(0);
      }
      return new Uint8Array(bytes.reverse());
    }
    console.log("%c[Word Finance]%c Wallet ready \u2720", "color:#9333ea;font-weight:bold", "color:inherit");
  })();
})();
