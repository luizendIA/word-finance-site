(() => {
  // ====================================================================
  // WORD FINANCE EXTENSION v1.1 — popup.js
  // Lightning, envio direto, cotacoes, historico, PIX, tema
  // Soli Deo Gloria
  // ====================================================================

  // --- Helpers ---
  function $(id) { return document.getElementById(id); }

  function showScreen(id) {
    document.querySelectorAll('.screen').forEach(function(s) { s.classList.remove('active'); });
    var el = $(id);
    if (el) el.classList.add('active');
  }

  function aviso(msg, type) {
    var t = $('toast');
    if (!t) return;
    t.textContent = msg;
    t.className = 'toast' + (type ? ' ' + type : '');
    t.style.display = 'block';
    setTimeout(function() { t.style.display = 'none'; }, 3500);
  }

  function sendBg(action, data) {
    return new Promise(function(resolve, reject) {
      chrome.runtime.sendMessage(
        { source: 'wf-popup', action: action, data: data || {} },
        function(resp) {
          if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
          if (resp && resp.error) return reject(new Error(resp.error));
          resolve(resp ? resp.result : null);
        }
      );
    });
  }

  // --- WordServer API ---
  var WORDSERVER = 'https://webhook.wordfinance.org';

  function getWordServer() {
    return WORDSERVER;
  }

  async function wordServerFetch(path, opts) {
    var url = getWordServer() + path;
    var res = await fetch(url, opts || {});
    if (!res.ok) throw new Error('WordServer: ' + res.status);
    return res.json();
  }

  // --- State ---
  var addr = '';
  var ba = { sol: 0, usdc: 0, pixc: 0 };
  var prices = { sol: 0, btc: 0, usdBrl: 5.5 };
  var lnBalanceSats = 0;
  var btcOnchain = { balance: 0, address: '' };
  var pinBuffer = '';
  var unlockBuffer = '';
  var pinStep = 'create';
  var firstPin = '';
  var currentSeed = '';
  var displayCurrency = 'USD'; // USD or BRL
  var tempPassword = ''; // senha temporaria ate criar PIN

  var PIN_KDF_ITERATIONS = 210000;

  function legacyPinToPassword(pin) {
    return 'wf_pin_' + pin + '_2026';
  }

  function bytesToBase64(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
    return btoa(s);
  }

  function base64ToBytes(b64) {
    var raw = atob(b64);
    var out = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
  }

  function secureStringEqual(a, b) {
    if (!a || !b) return false;
    var diff = a.length ^ b.length;
    var max = Math.max(a.length, b.length);
    for (var i = 0; i < max; i++) {
      diff |= (a.charCodeAt(i) || 0) ^ (b.charCodeAt(i) || 0);
    }
    return diff === 0;
  }

  async function derivePinMaterial(pin, saltB64, label) {
    var enc = new TextEncoder();
    var keyMaterial = await crypto.subtle.importKey(
      'raw',
      enc.encode(label + ':' + pin),
      'PBKDF2',
      false,
      ['deriveBits']
    );
    var bits = await crypto.subtle.deriveBits(
      { name: 'PBKDF2', salt: base64ToBytes(saltB64), iterations: PIN_KDF_ITERATIONS, hash: 'SHA-256' },
      keyMaterial,
      256
    );
    return bytesToBase64(new Uint8Array(bits));
  }

  async function buildPinCredentials(pin, saltB64) {
    var salt = saltB64 || bytesToBase64(crypto.getRandomValues(new Uint8Array(16)));
    var verifier = await derivePinMaterial(pin, salt, 'wf-pin-verifier-v2');
    var walletKey = await derivePinMaterial(pin, salt, 'wf-wallet-password-v2');
    return {
      salt: salt,
      verifier: verifier,
      password: 'wf_pin_v2_' + walletKey
    };
  }

  function getPinStorage() {
    return new Promise(function(resolve) {
      chrome.storage.local.get(['wf_pin', 'wf_pin_salt', 'wf_pin_verifier', 'wf_pin_version'], resolve);
    });
  }

  function setPinStorage(data) {
    return new Promise(function(resolve) {
      chrome.storage.local.set(data, resolve);
    });
  }

  function removePinKeys(keys) {
    return new Promise(function(resolve) {
      chrome.storage.local.remove(keys, resolve);
    });
  }

  async function savePinCredentials(creds) {
    await setPinStorage({
      wf_pin_salt: creds.salt,
      wf_pin_verifier: creds.verifier,
      wf_pin_version: 2
    });
    await removePinKeys(['wf_pin']);
  }

  async function getPasswordFromPin(pin) {
    var data = await getPinStorage();
    if (data.wf_pin_verifier && data.wf_pin_salt) {
      var creds = await buildPinCredentials(pin, data.wf_pin_salt);
      if (!secureStringEqual(creds.verifier, data.wf_pin_verifier)) {
        throw new Error('PIN incorreto');
      }
      return { password: creds.password, legacy: false };
    }
    if (data.wf_pin) {
      var savedPin = atob(data.wf_pin);
      if (pin !== savedPin) throw new Error('PIN incorreto');
      return { password: legacyPinToPassword(pin), legacy: true };
    }
    throw new Error('PIN nao configurado');
  }

  async function promptForWalletPassword(message) {
    var pin = prompt(message || 'Digite seu PIN:');
    if (!pin) return null;
    var auth = await getPasswordFromPin(pin);
    auth.pin = pin;
    return auth;
  }

  // --- PIN Pad ---
  function buildPinPad(containerId, handler) {
    var keys = ['1','2','3','4','5','6','7','8','9','','0','del'];
    var html = '';
    keys.forEach(function(k) {
      if (k === '') {
        html += '<div class="pin-key" style="visibility:hidden"></div>';
      } else if (k === 'del') {
        html += '<div class="pin-key" data-key="del">&#9003;</div>';
      } else {
        html += '<div class="pin-key" data-key="' + k + '">' + k + '</div>';
      }
    });
    var el = $(containerId);
    if (el) {
      el.innerHTML = html;
      el.querySelectorAll('.pin-key[data-key]').forEach(function(key) {
        key.addEventListener('click', function() { handler(this.dataset.key); });
      });
    }
  }

  function updateDots(prefix, buffer) {
    for (var i = 0; i < 4; i++) {
      var d = $(prefix + 'dot' + i);
      if (d) {
        if (i < buffer.length) d.classList.add('filled');
        else d.classList.remove('filled');
      }
    }
  }

  function handlePinCreate(key) {
    if (key === 'del') { pinBuffer = pinBuffer.slice(0, -1); updateDots('', pinBuffer); return; }
    if (pinBuffer.length < 4) { pinBuffer += key; updateDots('', pinBuffer); }
    if (pinBuffer.length === 4) {
      setTimeout(async function() {
        if (pinStep === 'create') {
          firstPin = pinBuffer; pinBuffer = ''; pinStep = 'confirm';
          $('pinTitle').textContent = 'Confirme o PIN';
          $('pinSubtitle').textContent = 'Digite novamente para confirmar';
          updateDots('', pinBuffer);
          return;
        }
        if (pinStep === 'confirm') {
          if (pinBuffer !== firstPin) {
            aviso('PINs n\u00e3o conferem!', 'error');
            firstPin = ''; pinBuffer = ''; pinStep = 'create';
            $('pinTitle').textContent = 'Crie um PIN';
            $('pinSubtitle').textContent = '4 d\u00edgitos para proteger seu app';
            updateDots('', pinBuffer);
            return;
          }
          try {
            if (!tempPassword) throw new Error('Senha atual nao encontrada');
            var creds = await buildPinCredentials(firstPin);
            await sendBg('changePassword', { oldPassword: tempPassword, newPassword: creds.password });
            await savePinCredentials(creds);
            tempPassword = '';
            firstPin = '';
            pinBuffer = '';
            aviso('PIN seguro configurado!', 'success');
            enterMainApp();
          } catch(e) {
            aviso('Erro ao salvar PIN: ' + e.message, 'error');
            firstPin = ''; pinBuffer = ''; pinStep = 'create';
            updateDots('', pinBuffer);
          }
        }
      }, 200);
    }
  }

  function handlePinUnlock(key) {
    if (key === 'del') { unlockBuffer = unlockBuffer.slice(0, -1); updateDots('u', unlockBuffer); return; }
    if (unlockBuffer.length < 4) { unlockBuffer += key; updateDots('u', unlockBuffer); }
    if (unlockBuffer.length === 4) {
      setTimeout(async function() {
        var enteredPin = unlockBuffer;
        unlockBuffer = '';
        updateDots('u', unlockBuffer);
        try {
          var auth = await getPasswordFromPin(enteredPin);
          var usedPassword = auth.password;
          var res;
          try {
            res = await sendBg('unlock', { password: usedPassword });
          } catch(e1) {
            if (!auth.legacy) throw e1;
            usedPassword = enteredPin;
            res = await sendBg('unlock', { password: usedPassword });
          }
          addr = res.publicKey;
          if (auth.legacy) {
            try {
              var creds = await buildPinCredentials(enteredPin);
              await sendBg('changePassword', { oldPassword: usedPassword, newPassword: creds.password });
              await savePinCredentials(creds);
            } catch(e2) {
              console.warn('[WF] Migracao de PIN legado falhou:', e2.message);
            }
          }
          enterMainApp();
        } catch(e) {
          aviso(e.message || 'PIN incorreto!', 'error');
        }
      }, 200);
    }
  }

  // --- Main App Entry ---
  function enterMainApp() {
    showScreen('mainApp');
    if (addr) {
      $('solAddress').textContent = addr;
      $('usdcAddress').textContent = addr;
      $('pixcAddress').textContent = addr;
    }
    loadBalances();
    loadPrices();
    loadLightningBalance();
    loadBtcOnchain();
    loadTheme();
    loadWordServerUrl();
    setTimeout(updateAddressQRs, 300);
  }

  // --- Prices (CoinGecko) ---
  async function loadPrices() {
    try {
      var res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=solana,bitcoin&vs_currencies=usd,brl');
      var data = await res.json();
      prices.sol = data.solana ? data.solana.usd : 150;
      prices.btc = data.bitcoin ? data.bitcoin.usd : 100000;
      prices.usdBrl = data.solana && data.solana.brl && data.solana.usd
        ? data.solana.brl / data.solana.usd : 5.5;
      calcularTotal();
    } catch(e) {
      prices.sol = 150; prices.btc = 100000; prices.usdBrl = 5.5;
    }
  }

  // --- Solana Balances ---
  function loadBalances() {
    sendBg('getBalances').then(function(b) {
      ba.sol = b.sol || 0;
      ba.usdc = b.usdc || 0;
      ba.pixc = b.pixc || 0;
      $('solBalance').textContent = ba.sol.toFixed(4) + ' SOL';
      $('usdcBalance').textContent = ba.usdc.toFixed(2) + ' USDC';
      $('pixcBalance').textContent = 'R$ ' + ba.pixc.toFixed(2).replace('.', ',');
      // Fiat values
      $('solFiat').textContent = '$ ' + (ba.sol * prices.sol).toFixed(2);
      $('usdcFiat').textContent = '$ ' + ba.usdc.toFixed(2);
      $('pixcFiat').textContent = '$ ' + (ba.pixc / prices.usdBrl).toFixed(2);
      calcularTotal();
    }).catch(function(e) {
      console.error('[WF] Erro carregando saldos:', e.message);
      $('solBalance').textContent = 'Erro RPC';
      $('usdcBalance').textContent = 'Erro RPC';
      $('pixcBalance').textContent = 'Erro RPC';
    });
  }

  // --- Lightning Balance ---
  var lnWalletCreated = false;

  async function ensureLightningWallet() {
    if (lnWalletCreated) return true;
    try {
      var walletData = await wordServerFetch('/api/lightning/wallet/' + addr);
      lnWalletCreated = true;
      return walletData;
    } catch(e) {
      // Wallet nao existe — criar automaticamente
      try {
        var created = await wordServerFetch('/api/lightning/create-wallet', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ solanaAddress: addr })
        });
        lnWalletCreated = true;
        console.log('[WF] Lightning wallet criada:', JSON.stringify(created));
        return created;
      } catch(e2) {
        console.warn('[WF] Nao criou Lightning wallet:', e2.message);
        return null;
      }
    }
  }

  async function loadLightningBalance() {
    if (!addr) return;
    var statusEl = $('lnStatus');
    if (statusEl) statusEl.textContent = 'Conectando...';
    try {
      var walletInfo = await ensureLightningWallet();
      var walletId = '';
      if (walletInfo && walletInfo.walletId) walletId = walletInfo.walletId;
      if (walletInfo && walletInfo.wallet_id) walletId = walletInfo.wallet_id;

      // Tentar endpoint de balance primeiro
      var balanceSats = 0;
      try {
        var data = await wordServerFetch('/api/lightning/balance/' + addr);
        console.log('[WF] LN balance raw:', JSON.stringify(data));
        var raw = data.balanceSats || data.balance || 0;
        // Se veio balanceSats, ja esta em sats. Se veio balance em msats, converter
        balanceSats = data.balanceSats ? raw : (raw > 10000 ? Math.floor(raw / 1000) : raw);
        if (statusEl) statusEl.textContent = 'Conectado' + (walletId ? ' (' + walletId.substring(0, 8) + '...)' : '');
        if (statusEl) statusEl.style.color = 'var(--green)';
      } catch(e1) {
        console.warn('[WF] LN balance endpoint falhou:', e1.message);
        // Fallback: pegar balance do endpoint /wallet/
        if (walletInfo && walletInfo.balance !== undefined) {
          var raw2 = walletInfo.balance || 0;
          balanceSats = raw2 > 10000 ? Math.floor(raw2 / 1000) : raw2;
        }
        if (statusEl) statusEl.textContent = 'Wallet: ' + (walletId || 'nenhuma');
        if (statusEl) statusEl.style.color = 'var(--accent)';
      }

      lnBalanceSats = balanceSats;
      $('lnBalance').textContent = lnBalanceSats.toLocaleString() + ' sats';
      var btcVal = lnBalanceSats / 100000000;
      $('lnFiat').textContent = '$ ' + (btcVal * prices.btc).toFixed(2);
      calcularTotal();
    } catch(e) {
      console.warn('[WF] Lightning erro geral:', e.message);
      $('lnBalance').textContent = '0 sats';
      $('lnFiat').textContent = '---';
      if (statusEl) { statusEl.textContent = 'Erro: ' + e.message; statusEl.style.color = 'var(--red)'; }
    }
  }

  // --- BTC On-chain ---
  async function loadBtcOnchain() {
    if (!addr) return;
    try {
      // Get address
      var addrData = await wordServerFetch('/api/btc/address/' + addr);
      btcOnchain.address = addrData.address || '';
      $('btcOnchainAddress').textContent = btcOnchain.address || 'Sem endere\u00e7o';
      if (btcOnchain.address) generateQR('qrBtcOnchain', 'bitcoin:' + btcOnchain.address, 140);
      // Get balance com solanaAddress
      try {
        var balData = await wordServerFetch('/api/btc/balance/' + addr);
        var confirmed = balData.confirmed || balData.total_balance || 0;
        btcOnchain.balance = confirmed / 100000000;
      } catch(e2) {
        btcOnchain.balance = 0;
      }
      $('btcOnchainBalance').textContent = btcOnchain.balance.toFixed(8) + ' BTC';
      calcularTotal();
    } catch(e) {
      console.warn('[WF] BTC on-chain:', e.message);
      $('btcOnchainAddress').textContent = 'Indispon\u00edvel';
      $('btcOnchainBalance').textContent = '0.00000000 BTC';
    }
  }

  // --- Total Balance ---
  function calcularTotal() {
    var solUsd = ba.sol * prices.sol;
    var usdcUsd = ba.usdc;
    var pixcUsd = ba.pixc / prices.usdBrl;
    var lnUsd = (lnBalanceSats / 100000000) * prices.btc;
    var btcUsd = btcOnchain.balance * prices.btc;
    var totalUsd = solUsd + usdcUsd + pixcUsd + lnUsd + btcUsd;

    if (displayCurrency === 'BRL') {
      var totalBrl = totalUsd * prices.usdBrl;
      $('totalBalance').textContent = 'R$ ' + totalBrl.toFixed(2).replace('.', ',');
      $('balanceCurrency').textContent = 'BRL';
    } else {
      $('totalBalance').textContent = '$ ' + totalUsd.toFixed(2);
      $('balanceCurrency').textContent = 'USD';
    }

    var lnSats = lnBalanceSats > 0 ? lnBalanceSats.toLocaleString() + ' sats' : '';

    $('breakdown').innerHTML =
      '<span class="breakdown-item"><span class="dot" style="background:#9945FF"></span>' + ba.sol.toFixed(3) + ' SOL</span>' +
      '<span class="breakdown-item"><span class="dot" style="background:#2775ca"></span>' + ba.usdc.toFixed(2) + ' USDC</span>' +
      '<span class="breakdown-item"><span class="dot" style="background:#10b981"></span>R$ ' + ba.pixc.toFixed(2).replace('.', ',') + '</span>' +
      (lnSats ? '<span class="breakdown-item"><span class="dot" style="background:#f7931a"></span>' + lnSats + '</span>' : '');
  }

  // --- Tabs ---
  function setupTabs() {
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var tab = this.dataset.tab;
        document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
        this.classList.add('active');
        document.querySelectorAll('.panel').forEach(function(p) { p.classList.remove('active'); });
        var panel = $('panel-' + tab);
        if (panel) panel.classList.add('active');
      });
    });
  }

  function showPanel(panelId) {
    document.querySelectorAll('.panel').forEach(function(p) { p.classList.remove('active'); });
    $(panelId).classList.add('active');
    document.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
  }

  function backToMais() {
    showPanel('panel-mais');
    document.querySelector('.tab-btn[data-tab="mais"]').classList.add('active');
  }

  // --- Send SOL/USDC/PIXC ---
  function setupSend() {
    $('btnSendSol').addEventListener('click', async function() {
      var to = $('solSendAddr').value.trim();
      var amt = parseFloat($('solSendAmount').value);
      if (!to || !amt || amt <= 0) return aviso('Preencha endere\u00e7o e valor', 'error');
      if (amt > ba.sol) return aviso('Saldo SOL insuficiente', 'error');
      try {
        this.disabled = true; this.textContent = 'Enviando...';
        var res = await sendBg('sendSol', { toAddress: to, amount: amt });
        aviso('SOL enviado! TX: ' + (res.signature || '').substring(0, 12) + '...', 'success');
        $('solSendAddr').value = ''; $('solSendAmount').value = '';
        setTimeout(loadBalances, 2000);
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      } finally {
        this.disabled = false; this.textContent = 'Enviar SOL';
      }
    });

    $('btnSendUsdc').addEventListener('click', async function() {
      var to = $('usdcSendAddr').value.trim();
      var amt = parseFloat($('usdcSendAmount').value);
      if (!to || !amt || amt <= 0) return aviso('Preencha endere\u00e7o e valor', 'error');
      if (amt > ba.usdc) return aviso('Saldo USDC insuficiente', 'error');
      try {
        this.disabled = true; this.textContent = 'Enviando...';
        var res = await sendBg('sendToken', {
          toAddress: to, amount: amt,
          mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
          decimals: 6
        });
        aviso('USDC enviado!', 'success');
        $('usdcSendAddr').value = ''; $('usdcSendAmount').value = '';
        setTimeout(loadBalances, 2000);
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      } finally {
        this.disabled = false; this.textContent = 'Enviar USDC';
      }
    });

    $('btnSendPixc').addEventListener('click', async function() {
      var to = $('pixcSendAddr').value.trim();
      var amt = parseFloat($('pixcSendAmount').value);
      if (!to || !amt || amt <= 0) return aviso('Preencha endere\u00e7o e valor', 'error');
      if (amt > ba.pixc) return aviso('Saldo PIXC insuficiente', 'error');
      try {
        this.disabled = true; this.textContent = 'Enviando...';
        var res = await sendBg('sendToken', {
          toAddress: to, amount: amt,
          mint: 'AJAb19vFHfZg1Bs4eYkL2NXjHeuRXNPG8wry8p1f26fq',
          decimals: 2
        });
        aviso('PIXC enviado!', 'success');
        $('pixcSendAddr').value = ''; $('pixcSendAmount').value = '';
        setTimeout(loadBalances, 2000);
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      } finally {
        this.disabled = false; this.textContent = 'Enviar PIXC';
      }
    });
  }

  // --- Lightning: Create Invoice ---
  function setupLightning() {
    $('btnCreateInvoice').addEventListener('click', async function() {
      var amount = parseInt($('lnInvoiceAmount').value);
      var memo = $('lnInvoiceMemo').value.trim() || 'Word Finance';
      if (!amount || amount < 1) return aviso('Valor m\u00ednimo: 1 sat', 'error');
      try {
        this.disabled = true; this.textContent = 'Gerando...';
        var data = await wordServerFetch('/api/lightning/invoice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ solanaAddress: addr, amountSats: amount, memo: memo })
        });
        $('lnInvoiceText').textContent = data.invoice || data.payment_request || '---';
        $('lnInvoiceResult').style.display = 'block';
        var inv = data.invoice || data.payment_request || '';
        if (inv) generateQR('qrLnInvoice', 'lightning:' + inv, 180);
        aviso('Invoice criado!', 'success');
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      } finally {
        this.disabled = false; this.textContent = '\u26A1 Gerar Invoice';
      }
    });

    $('lnInvoiceText').addEventListener('click', function() {
      navigator.clipboard.writeText(this.textContent).then(function() {
        aviso('Invoice copiado!', 'success');
      });
    });

    $('btnPayInvoice').addEventListener('click', async function() {
      var invoice = $('lnPayInvoice').value.trim();
      if (!invoice) return aviso('Cole uma invoice Lightning', 'error');
      if (!invoice.startsWith('lnbc') && !invoice.startsWith('LNBC'))
        return aviso('Invoice inv\u00e1lida (deve come\u00e7ar com lnbc)', 'error');
      try {
        this.disabled = true; this.textContent = 'Pagando...';
        var data = await wordServerFetch('/api/lightning/pay', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ solanaAddress: addr, invoice: invoice })
        });
        aviso('Pagamento Lightning enviado!', 'success');
        $('lnPayInvoice').value = '';
        setTimeout(loadLightningBalance, 2000);
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      } finally {
        this.disabled = false; this.textContent = '\u26A1 Pagar Invoice';
      }
    });

    $('btnRefreshLn').addEventListener('click', loadLightningBalance);
    $('btnRefreshBtc').addEventListener('click', loadBtcOnchain);
  }

  // --- Deposit PIX ---
  function setupDeposit() {
    $('depositAmount').addEventListener('input', function() {
      var val = parseFloat(this.value) || 0;
      var fee = val * 0.005 + 0.80;
      var receive = Math.max(0, val - fee);
      $('depositReceive').textContent = receive.toFixed(2).replace('.', ',') + ' PIXC';
    });

    $('btnCreateDeposit').addEventListener('click', async function() {
      var val = parseFloat($('depositAmount').value);
      if (!val || val < 1) return aviso('Valor m\u00ednimo: R$ 1,00', 'error');
      try {
        this.disabled = true; this.textContent = 'Gerando...';
        var data = await wordServerFetch('/api/deposit/pix/create', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ walletAddress: addr, valorReais: val })
        });
        $('depositPixCode').textContent = data.brCode || '---';
        $('depositStatus').textContent = 'Aguardando pagamento...';
        $('depositResult').style.display = 'block';
        if (data.brCode) generateQR('qrDeposit', data.brCode, 180);
        aviso('QR PIX gerado!', 'success');
        // Poll status
        if (data.pixId) pollDepositStatus(data.pixId);
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      } finally {
        this.disabled = false; this.textContent = 'Gerar QR PIX';
      }
    });

    $('depositPixCode').addEventListener('click', function() {
      navigator.clipboard.writeText(this.textContent).then(function() {
        aviso('C\u00f3digo PIX copiado!', 'success');
      });
    });
  }

  function pollDepositStatus(pixId) {
    var attempts = 0;
    var interval = setInterval(async function() {
      attempts++;
      if (attempts > 60) { clearInterval(interval); return; }
      try {
        var data = await wordServerFetch('/api/deposit/pix/status/' + pixId);
        if (data.status === 'COMPLETED' || data.minted) {
          $('depositStatus').textContent = 'Pago! PIXC creditado.';
          $('depositStatus').style.color = 'var(--green)';
          clearInterval(interval);
          setTimeout(loadBalances, 1000);
        } else if (data.status === 'EXPIRED') {
          $('depositStatus').textContent = 'Expirado';
          $('depositStatus').style.color = 'var(--red)';
          clearInterval(interval);
        }
      } catch(e) { /* continue polling */ }
    }, 5000);
  }

  // --- History ---
  async function loadHistory() {
    var list = $('historyList');
    list.innerHTML = '<div class="loading">Carregando</div>';
    try {
      var res = await fetch(
        'https://api.helius.xyz/v0/addresses/' + addr + '/transactions?api-key=05918f7b-c6ec-4ada-bbc1-52349cedb334&limit=15'
      );
      var txs = await res.json();
      if (!txs || txs.length === 0) {
        list.innerHTML = '<div class="history-empty">Nenhuma transa\u00e7\u00e3o encontrada</div>';
        return;
      }
      var html = '';
      txs.forEach(function(tx) {
        var type = tx.type || 'UNKNOWN';
        var desc = tx.description || type;
        var timestamp = tx.timestamp ? new Date(tx.timestamp * 1000).toLocaleDateString('pt-BR') : '';
        var iconClass = 'swap';
        var amountText = '';

        if (type === 'TRANSFER') {
          // Check if sent or received
          var nativeTransfers = tx.nativeTransfers || [];
          var tokenTransfers = tx.tokenTransfers || [];
          var isSent = false;
          nativeTransfers.forEach(function(nt) {
            if (nt.fromUserAccount === addr) { isSent = true; amountText = '-' + (nt.amount / 1e9).toFixed(4) + ' SOL'; }
            else if (nt.toUserAccount === addr) { amountText = '+' + (nt.amount / 1e9).toFixed(4) + ' SOL'; }
          });
          tokenTransfers.forEach(function(tt) {
            if (tt.fromUserAccount === addr) { isSent = true; amountText = '-' + tt.tokenAmount; }
            else if (tt.toUserAccount === addr) { amountText = '+' + tt.tokenAmount; }
          });
          iconClass = isSent ? 'sent' : 'received';
        } else if (type === 'SWAP') {
          iconClass = 'swap';
          amountText = 'Swap';
        }

        var iconSymbol = iconClass === 'sent' ? '\u2191' : iconClass === 'received' ? '\u2193' : '\u21C4';
        var amountClass = iconClass === 'sent' ? 'negative' : iconClass === 'received' ? 'positive' : '';

        html += '<div class="history-item" title="' + (tx.signature || '') + '">' +
          '<div class="history-icon ' + iconClass + '">' + iconSymbol + '</div>' +
          '<div class="history-info"><div class="history-type">' + type + '</div>' +
          '<div class="history-date">' + timestamp + '</div></div>' +
          '<div class="history-amount ' + amountClass + '">' + amountText + '</div></div>';
      });
      list.innerHTML = html;

      // Click to open on Solscan
      list.querySelectorAll('.history-item').forEach(function(item) {
        item.addEventListener('click', function() {
          var sig = this.title;
          if (sig) window.open('https://solscan.io/tx/' + sig, '_blank');
        });
      });
    } catch(e) {
      list.innerHTML = '<div class="history-empty">Erro ao carregar: ' + e.message + '</div>';
    }
  }

  // --- Connected Sites ---
  function loadConnectedSites() {
    var list = $('connectedList');
    sendBg('getConnectedSites').then(function(sites) {
      if (!sites || Object.keys(sites).length === 0) {
        list.innerHTML = '<div class="history-empty">Nenhum site conectado</div>';
        return;
      }
      var html = '';
      Object.keys(sites).forEach(function(origin) {
        html += '<div class="connected-item">' +
          '<span class="connected-origin">' + origin + '</span>' +
          '<button class="connected-disconnect" data-origin="' + origin + '">Desconectar</button>' +
          '</div>';
      });
      list.innerHTML = html;
      list.querySelectorAll('.connected-disconnect').forEach(function(btn) {
        btn.addEventListener('click', function() {
          var origin = this.dataset.origin;
          sendBg('disconnectSite', { origin: origin }).then(function() {
            aviso('Site desconectado', 'success');
            loadConnectedSites();
          });
        });
      });
    }).catch(function() {
      list.innerHTML = '<div class="history-empty">Nenhum site conectado</div>';
    });
  }

  // --- Theme ---
  function loadTheme() {
    chrome.storage.local.get('wf_theme', function(data) {
      var theme = data.wf_theme || 'dark';
      document.documentElement.setAttribute('data-theme', theme);
    });
  }

  function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    chrome.storage.local.set({ wf_theme: theme });
    aviso('Tema ' + (theme === 'dark' ? 'escuro' : 'claro') + ' ativado', 'success');
  }

  // --- WordServer URL ---
  function loadWordServerUrl() {
    chrome.storage.local.get('wf_wordserver', function(data) {
      if (data.wf_wordserver) {
        WORDSERVER = data.wf_wordserver;
        if ($('settingsWordServer')) $('settingsWordServer').value = WORDSERVER;
      }
    });
  }

  // --- QR Code Generation ---
  function generateQR(containerId, data, size) {
    if (!data || data === '---' || data === 'Carregando...') return;
    var container = $(containerId);
    if (!container) return;
    size = size || 160;
    container.innerHTML = '';
    try {
      new QRCode(container, {
        text: data,
        width: size,
        height: size,
        colorDark: '#ffffff',
        colorLight: '#0d0d1a',
        correctLevel: QRCode.CorrectLevel.M
      });
    } catch(e) {
      container.textContent = 'QR indisponivel';
    }
  }

  function updateAddressQRs() {
    if (!addr || addr === '---') return;
    generateQR('qrSol', addr, 140);
    generateQR('qrUsdc', addr, 140);
    generateQR('qrPixc', addr, 140);
  }

  // --- Address Copy ---
  function setupAddressCopy() {
    ['solAddress', 'usdcAddress', 'pixcAddress', 'btcOnchainAddress'].forEach(function(id) {
      $(id).addEventListener('click', function() {
        navigator.clipboard.writeText(this.textContent).then(function() {
          aviso('Endere\u00e7o copiado!', 'success');
        });
      });
    });
  }

  // --- Currency Toggle ---
  function setupCurrencyToggle() {
    $('balanceCurrency').addEventListener('click', function() {
      displayCurrency = displayCurrency === 'USD' ? 'BRL' : 'USD';
      calcularTotal();
    });
  }

  // ====================================================================
  // INIT
  // ====================================================================
  document.addEventListener('DOMContentLoaded', function() {
    buildPinPad('pinPadCreate', handlePinCreate);
    buildPinPad('pinPadUnlock', handlePinUnlock);
    setupTabs();
    setupSend();
    setupLightning();
    setupDeposit();
    setupAddressCopy();
    setupCurrencyToggle();

    // --- Welcome buttons ---
    $('btnNewWallet').addEventListener('click', function() {
      tempPassword = 'wf_ext_' + Date.now();
      sendBg('createWallet', { password: tempPassword }).then(function(res) {
        addr = res.publicKey;
        currentSeed = res.mnemonic;
        $('seedDisplay').textContent = currentSeed;
        showScreen('screen-create');
      }).catch(function(e) { aviso('Erro: ' + e.message, 'error'); });
    });

    $('btnImportWallet').addEventListener('click', function() { showScreen('screen-import'); });

    $('btnCopySeed').addEventListener('click', function() {
      navigator.clipboard.writeText(currentSeed).then(function() { aviso('Seed copiada!', 'success'); });
    });

    function updateSeedDoneState() {
      var ok = $('seedConfirmed').checked && $('termsAccepted').checked;
      $('btnSeedDone').disabled = !ok;
      $('btnSeedDone').style.opacity = ok ? '1' : '0.5';
    }
    $('seedConfirmed').addEventListener('change', updateSeedDoneState);
    $('termsAccepted').addEventListener('change', updateSeedDoneState);

    $('importTermsAccepted').addEventListener('change', function() {
      $('btnImportConfirm').disabled = !this.checked;
      $('btnImportConfirm').style.opacity = this.checked ? '1' : '0.5';
    });

    $('btnSeedDone').addEventListener('click', function() {
      pinStep = 'create'; firstPin = ''; pinBuffer = '';
      $('pinTitle').textContent = 'Crie um PIN';
      $('pinSubtitle').textContent = '4 d\u00edgitos para proteger seu app';
      updateDots('', ''); showScreen('screen-pin-create');
    });

    $('btnImportConfirm').addEventListener('click', function() {
      var seed = $('importSeedInput').value.trim();
      if (!seed) return aviso('Cole sua seed', 'error');
      if (!$('importTermsAccepted').checked) return aviso('Aceite os termos para continuar', 'error');
      tempPassword = 'wf_ext_' + Date.now();
      sendBg('importWallet', { mnemonic: seed, password: tempPassword }).then(function(res) {
        addr = res.publicKey; aviso('Carteira importada!', 'success');
        pinStep = 'create'; firstPin = ''; pinBuffer = '';
        updateDots('', ''); showScreen('screen-pin-create');
      }).catch(function(e) { aviso('Erro: ' + e.message, 'error'); });
    });

    $('btnImportBack').addEventListener('click', function() { showScreen('screen-welcome'); });

    // --- Refresh buttons ---
    $('btnRefreshSol').addEventListener('click', function() { loadBalances(); loadPrices(); });
    $('btnRefreshUsdc').addEventListener('click', function() { loadBalances(); loadPrices(); });
    $('btnRefreshPixc').addEventListener('click', function() { loadBalances(); loadPrices(); });

    // --- MAIS navigation ---
    $('btnDeposit').addEventListener('click', function() { showPanel('panel-deposit'); });
    $('btnDepositBack').addEventListener('click', backToMais);

    $('btnHistory').addEventListener('click', function() {
      showPanel('panel-history'); loadHistory();
    });
    $('btnHistoryBack').addEventListener('click', backToMais);

    $('btnConnectedSites').addEventListener('click', function() {
      showPanel('panel-connected'); loadConnectedSites();
    });
    $('btnConnectedBack').addEventListener('click', backToMais);

    $('btnPartners').addEventListener('click', function() { showPanel('panel-partners'); });
    $('btnPartnersBack').addEventListener('click', backToMais);

    $('btnGames').addEventListener('click', function() { showPanel('panel-games'); });
    $('btnGamesBack').addEventListener('click', backToMais);

    $('btnDappInfo').addEventListener('click', function() {
      aviso('Abra Jupiter/Raydium no Chrome \u2014 Word Finance aparece autom\u00e1tico!');
    });

    $('btnSettings').addEventListener('click', function() {
      showPanel('panel-settings');
      sendBg('getRpc').then(function(r) { $('settingsRpc').value = r.rpcUrl || ''; });
      chrome.storage.local.get('wf_wordserver', function(d) {
        $('settingsWordServer').value = d.wf_wordserver || 'https://webhook.wordfinance.org';
      });
    });
    $('btnSettingsBack').addEventListener('click', backToMais);

    $('btnAbout').addEventListener('click', function() { showPanel('panel-about'); });
    $('btnAboutBack').addEventListener('click', backToMais);

    $('btnLockWallet').addEventListener('click', function() {
      sendBg('lock');
      unlockBuffer = ''; updateDots('u', '');
      showScreen('screen-unlock');
    });

    // --- Settings actions ---
    $('btnSaveRpc').addEventListener('click', function() {
      var rpc = $('settingsRpc').value.trim();
      if (rpc) sendBg('setRpc', { rpcUrl: rpc }).then(function() { aviso('RPC salvo!', 'success'); });
    });

    $('btnSaveWordServer').addEventListener('click', function() {
      var ws = $('settingsWordServer').value.trim();
      if (ws) {
        WORDSERVER = ws;
        chrome.storage.local.set({ wf_wordserver: ws });
        aviso('WordServer salvo!', 'success');
      }
    });

    $('btnThemeDark').addEventListener('click', function() { setTheme('dark'); });
    $('btnThemeLight').addEventListener('click', function() { setTheme('light'); });

    $('btnSaveAutoLock').addEventListener('click', function() {
      var minutes = parseInt($('settingsAutoLock').value);
      sendBg('setAutoLock', { minutes: minutes }).then(function() {
        aviso('Auto-lock: ' + (minutes > 0 ? minutes + ' min' : 'Desativado'), 'success');
      });
    });

    $('btnExportSeed').addEventListener('click', async function() {
      try {
        var auth = await promptForWalletPassword('Digite seu PIN para revelar a seed:');
        if (!auth) return;
        var res;
        try {
          res = await sendBg('exportSeed', { password: auth.password });
        } catch(e1) {
          if (!auth.legacy) throw e1;
          res = await sendBg('exportSeed', { password: auth.pin });
        }
        $('exportSeedText').textContent = res.mnemonic;
        $('exportSeedBox').style.display = 'block';
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      }
    });

    $('btnHideExportSeed').addEventListener('click', function() {
      $('exportSeedText').textContent = '---';
      $('exportSeedBox').style.display = 'none';
    });

    $('btnChangePin').addEventListener('click', async function() {
      try {
        var auth = await promptForWalletPassword('Digite o PIN atual:');
        if (!auth) return;
        try {
          await sendBg('unlock', { password: auth.password });
          tempPassword = auth.password;
        } catch(e1) {
          if (!auth.legacy) throw e1;
          await sendBg('unlock', { password: auth.pin });
          tempPassword = auth.pin;
        }
        pinStep = 'create'; firstPin = ''; pinBuffer = '';
        updateDots('', '');
        $('pinTitle').textContent = 'Novo PIN';
        $('pinSubtitle').textContent = '4 d\u00edgitos para proteger seu app';
        showScreen('screen-pin-create');
      } catch(e) {
        aviso('Erro: ' + e.message, 'error');
      }
    });

    // --- Reset wallet (reimportar seed) ---
    $('btnResetWallet').addEventListener('click', function() {
      if (confirm('Tem certeza? Voce vai precisar da sua seed de 12 palavras pra reimportar.')) {
        chrome.storage.local.remove(['wf_pin', 'wf_pin_salt', 'wf_pin_verifier', 'wf_pin_version', 'wf_encrypted_seed', 'wf_has_wallet', 'wf_pubkey'], function() {
          aviso('Wallet resetada. Importe sua seed.', 'success');
          showScreen('screen-welcome');
        });
      }
    });

    // --- Init state ---
    loadTheme();
    sendBg('getState').then(function(state) {
      if (!state.hasWallet) {
        showScreen('screen-welcome');
      } else if (!state.isUnlocked) {
        chrome.storage.local.get(['wf_pin', 'wf_pin_verifier'], function(data) {
          if (data.wf_pin || data.wf_pin_verifier) showScreen('screen-unlock');
          else showScreen('screen-welcome');
        });
      } else {
        addr = state.publicKey;
        chrome.storage.local.get(['wf_pin', 'wf_pin_verifier'], function(data) {
          if (data.wf_pin || data.wf_pin_verifier) showScreen('screen-unlock');
          else enterMainApp();
        });
      }
    }).catch(function() { showScreen('screen-welcome'); });
  });
})();
