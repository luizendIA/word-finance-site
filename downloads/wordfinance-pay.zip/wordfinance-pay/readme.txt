=== Word Finance Pay - Bitcoin & USDC ===
Contributors: wordfinance
Tags: bitcoin, payment, lightning, usdc, crypto, woocommerce, gateway, solana, cryptocurrency
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Accept Bitcoin Lightning (0% fee) and USDC (1% fee) payments in your WooCommerce store. Non-custodial: funds go directly to your wallet.

== Description ==

**Word Finance Pay** is a non-custodial cryptocurrency payment gateway for WooCommerce. Accept Bitcoin via Lightning Network and USDC on Solana in your online store.

= Key Features =

* **Bitcoin Lightning** - Instant payments with 0% merchant fee
* **USDC (Solana)** - Stablecoin payments with only 1% fee
* **Non-custodial** - Funds go directly to your Solana wallet. We never hold your money
* **Automatic conversion** - Prices displayed in BRL, customer pays in crypto
* **Real-time rates** - Exchange rates updated via CoinGecko
* **QR Code checkout** - Customer scans and pays in seconds
* **Webhook notifications** - Automatic order confirmation when payment is received
* **Multi-language** - Works in any language

= How It Works =

1. Customer selects "Bitcoin & USDC" at checkout
2. A QR code is displayed with the exact crypto amount
3. Customer pays with any Bitcoin/Lightning or Solana wallet
4. Payment is confirmed automatically
5. You receive the funds directly in your wallet

= Business Model =

| Method | Merchant Fee | Speed |
|--------|-------------|-------|
| Lightning | 0% | Instant |
| USDC | 1% (atomic split) | ~5 seconds |

= Requirements =

* WooCommerce 5.0 or later
* A Solana wallet address (for USDC payments)
* No additional accounts or registrations needed

= About Word Finance =

Word Finance is a Brazilian fintech building sovereign financial infrastructure. Our payment gateway connects traditional e-commerce with the crypto economy, enabling merchants worldwide to accept Bitcoin and USDC with zero friction.

Website: [wordfinance.org](https://wordfinance.org)

== Installation ==

1. Upload the `wordfinance-pay` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to WooCommerce > Settings > Payments
4. Enable "Word Finance Pay"
5. Enter your Solana wallet address
6. Save changes - your Merchant ID will be generated automatically

That's it! Your customers can now pay with Bitcoin and USDC.

== Frequently Asked Questions ==

= Do I need a Word Finance account? =

No. You only need a Solana wallet address to receive USDC payments. Lightning payments are processed through the Word Finance network.

= Is this custodial? =

No. Word Finance Pay is 100% non-custodial. USDC payments go directly to your Solana wallet via atomic split on the blockchain. We never hold your funds.

= What currencies are supported? =

Prices are displayed in BRL (Brazilian Real) and automatically converted to BTC or USDC at real-time rates. Support for USD and EUR is planned.

= How fast are payments confirmed? =

Lightning payments are instant (less than 1 second). USDC payments on Solana take approximately 5 seconds.

= What happens if the customer doesn't pay? =

Charges expire after 15 minutes. The order will be automatically cancelled if no payment is received.

= Are there any fees? =

Lightning: 0% fee for merchants. USDC: 1% fee via atomic split (99% goes to you, 1% to Word Finance).

== Screenshots ==

1. Payment method selection at checkout
2. QR code payment page with Lightning and USDC options
3. Plugin settings in WooCommerce admin
4. Order confirmation with crypto payment details

== Changelog ==

= 1.0.0 =
* Initial release
* Bitcoin Lightning payments (0% fee)
* USDC payments on Solana (1% fee)
* Automatic merchant registration
* QR code payment page
* Webhook payment confirmation
* WooCommerce order status management

== Upgrade Notice ==

= 1.0.0 =
First stable release. Accept Bitcoin and USDC in your WooCommerce store.
