<?php
/**
 * Plugin Name: Word Finance Pay - Bitcoin & USDC
 * Plugin URI: https://wordfinance.org
 * Description: Aceite Bitcoin Lightning e USDC na sua loja WooCommerce. Gateway nao-custodial.
 * Version: 1.0.0
 * Author: Word Finance
 * Author URI: https://wordfinance.org
 * License: MIT
 * Text Domain: wordfinance-pay
 * Requires Plugins: woocommerce
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

defined('ABSPATH') || exit;

add_action('before_woocommerce_init', function() {
    if (class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

add_filter('woocommerce_payment_gateways', function($g) { $g[] = 'WC_Gateway_WordFinance'; return $g; });

add_action('plugins_loaded', function() {
    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_Gateway_WordFinance extends WC_Payment_Gateway {

        private $gateway_url;
        private $solana_wallet;
        private $merchant_id;

        public function __construct() {
            $this->id                 = 'wordfinance';
            $this->has_fields         = false;
            $this->method_title       = 'Word Finance Pay';
            $this->method_description = 'Aceite Bitcoin Lightning (0% taxa) e USDC (1% taxa). Nao-custodial.';
            $this->supports           = array('products');

            $this->init_form_fields();
            $this->init_settings();

            $this->title         = $this->get_option('title', 'Bitcoin & USDC');
            $this->description   = $this->get_option('description', 'Pague com Bitcoin Lightning ou USDC. Powered by Word Finance.');
            $this->enabled       = $this->get_option('enabled', 'no');
            $this->gateway_url   = rtrim($this->get_option('gateway_url', 'https://webhook.wordfinance.org'), '/');
            $this->solana_wallet = $this->get_option('solana_wallet', '');
            $this->merchant_id   = $this->get_option('merchant_id', '');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'auto_register_merchant'));
            add_action('woocommerce_api_wf_confirm', array($this, 'handle_webhook'));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
        }

        public function init_form_fields() {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Ativar', 'type' => 'checkbox', 'default' => 'no',
                ),
                'title' => array(
                    'title' => 'Titulo no checkout', 'type' => 'text', 'default' => 'Bitcoin & USDC',
                ),
                'description' => array(
                    'title' => 'Descricao', 'type' => 'textarea',
                    'default' => 'Pague com Bitcoin Lightning (instantaneo, 0%) ou USDC (Solana). Powered by Word Finance.',
                ),
                'gateway_url' => array(
                    'title' => 'URL do Gateway', 'type' => 'text',
                    'default' => 'https://webhook.wordfinance.org',
                    'description' => 'URL do servidor Word Finance.',
                ),
                'solana_wallet' => array(
                    'title' => 'Carteira Solana (USDC)', 'type' => 'text',
                    'description' => 'Endereco Solana para receber USDC.',
                ),
                'merchant_id' => array(
                    'title' => 'Merchant ID', 'type' => 'text',
                    'description' => 'Preenchido automaticamente ao salvar.',
                    'custom_attributes' => array('readonly' => 'readonly'),
                ),
            );
        }

        // Registra lojista automaticamente ao salvar configuracoes
        public function auto_register_merchant() {
            if (empty($this->solana_wallet)) return;
            if (!empty($this->merchant_id)) return;

            $response = wp_remote_post($this->gateway_url . '/api/gateway/merchant/register', array(
                'timeout' => 15,
                'headers' => array('Content-Type' => 'application/json'),
                'body'    => wp_json_encode(array(
                    'name'          => get_bloginfo('name'),
                    'solanaWallet'  => $this->solana_wallet,
                    'webhookUrl'    => home_url('/wc-api/wf_confirm'),
                    'platform'      => 'woocommerce',
                    'siteUrl'       => home_url(),
                )),
            ));

            if (!is_wp_error($response)) {
                $body = json_decode(wp_remote_retrieve_body($response), true);
                if (!empty($body['merchantId'])) {
                    $this->update_option('merchant_id', $body['merchantId']);
                    $this->merchant_id = $body['merchantId'];
                }
            }
        }

        // Processa pagamento
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                wc_add_notice('Erro ao processar pedido.', 'error');
                return array('result' => 'failure');
            }

            if (empty($this->merchant_id)) {
                wc_add_notice('Gateway nao configurado. Contate o lojista.', 'error');
                return array('result' => 'failure');
            }

            $response = wp_remote_post($this->gateway_url . '/api/gateway/charge', array(
                'timeout' => 30,
                'headers' => array('Content-Type' => 'application/json'),
                'body'    => wp_json_encode(array(
                    'merchantId'    => $this->merchant_id,
                    'amountBRL'     => (float) $order->get_total(),
                    'description'   => 'Pedido #' . $order_id . ' - ' . get_bloginfo('name'),
                    'orderId'       => (string) $order_id,
                    'customerEmail' => $order->get_billing_email(),
                    'customerName'  => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'webhookUrl'    => home_url('/wc-api/wf_confirm'),
                    'returnUrl'     => $this->get_return_url($order),
                    'platform'      => 'woocommerce',
                )),
            ));

            if (is_wp_error($response)) {
                wc_add_notice('Erro de conexao: ' . $response->get_error_message(), 'error');
                return array('result' => 'failure');
            }

            $body = json_decode(wp_remote_retrieve_body($response), true);

            if (empty($body['chargeId'])) {
                wc_add_notice('Erro: ' . ($body['error'] ?? 'Falha ao criar cobranca'), 'error');
                return array('result' => 'failure');
            }

            $order->update_meta_data('_wf_charge_id', $body['chargeId']);
            $order->set_status('pending', 'Aguardando pagamento crypto via Word Finance.');
            $order->save();

            $payment_url = $this->gateway_url . '/pay/' . $body['chargeId'];

            return array('result' => 'success', 'redirect' => $payment_url);
        }

        // Webhook de confirmacao
        public function handle_webhook() {
            $payload = json_decode(file_get_contents('php://input'), true);

            if (empty($payload['orderId']) || empty($payload['status'])) {
                wp_send_json(array('error' => 'Payload incompleto'), 400);
                return;
            }

            $order = wc_get_order((int) $payload['orderId']);
            if (!$order) {
                wp_send_json(array('error' => 'Pedido nao encontrado'), 404);
                return;
            }

            if ($payload['status'] === 'paid' || $payload['status'] === 'confirmed') {
                $method = $payload['paymentMethod'] ?? 'crypto';
                $order->payment_complete($payload['chargeId'] ?? '');
                $order->add_order_note('Pagamento confirmado via Word Finance (' . strtoupper($method) . ')');
                $order->save();
                wp_send_json(array('success' => true));
            } elseif ($payload['status'] === 'expired') {
                $order->update_status('cancelled', 'Pagamento expirado.');
                wp_send_json(array('success' => true));
            }
        }

        // Pagina de obrigado
        public function thankyou_page($order_id) {
            $order = wc_get_order($order_id);
            if (!$order) return;
            if ($order->get_status() === 'pending') {
                echo '<div style="background:#fff3cd;border:1px solid #ffc107;padding:16px;border-radius:8px;margin:16px 0;">';
                echo '<p><strong>Aguardando pagamento...</strong> Confirmacao automatica.</p></div>';
                echo '<script>setTimeout(function(){ location.reload(); }, 8000);</script>';
            } elseif (in_array($order->get_status(), ['processing', 'completed'])) {
                echo '<div style="background:#d4edda;border:1px solid #28a745;padding:16px;border-radius:8px;margin:16px 0;">';
                echo '<p><strong>Pagamento confirmado!</strong> Powered by Word Finance.</p></div>';
            }
        }
    }
});
