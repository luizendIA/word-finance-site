(() => {
  // src/content_script.js
  (function() {
    "use strict";
    const url = window.location.href;
    if (url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("about:")) {
      return;
    }
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("inpage.js");
    script.type = "text/javascript";
    script.onload = function() {
      this.remove();
    };
    (document.head || document.documentElement).appendChild(script);
    window.addEventListener("wf-extension-request", (e) => {
      if (!e.detail || typeof e.detail.id !== "string" || e.detail.id.length > 160 || typeof e.detail.type !== "string") {
        return;
      }
      const { id, type, data } = e.detail;
      chrome.runtime.sendMessage(
        { source: "wf-content", id, type, data, origin: window.location.origin },
        (response) => {
          if (chrome.runtime.lastError) {
            dispatchResponse(id, null, "Word Finance: extension not available");
            return;
          }
          if (response && response.error) {
            dispatchResponse(id, null, response.error);
          } else if (response) {
            dispatchResponse(id, response.result, null);
          }
        }
      );
    });
    function dispatchResponse(id, result, error) {
      window.dispatchEvent(new CustomEvent("wf-extension-response", {
        detail: { id, result, error }
      }));
    }
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg.source === "wf-background") {
        if (msg.type === "accountChanged") {
          window.dispatchEvent(new CustomEvent("wf-extension-response", {
            detail: { id: "__event__", result: { event: "accountChanged", data: msg.data } }
          }));
        }
      }
    });
  })();
})();
