(() => {
  // src/approve.js
  function $(id) {
    return document.getElementById(id);
  }
  function sendToBackground(action, data) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { source: "wf-popup", action, data: data || {} },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (response?.error) reject(new Error(response.error));
          else resolve(response?.result);
        }
      );
    });
  }
  var TYPE_LABELS = {
    connect: "Conectar Site",
    signMessage: "Assinar Mensagem",
    signTransaction: "Assinar Transa\xE7\xE3o",
    signAndSendTransaction: "Assinar e Enviar Transa\xE7\xE3o"
  };
  document.addEventListener("DOMContentLoaded", async () => {
    const params = new URLSearchParams(window.location.search);
    const requestId = params.get("id");
    const type = params.get("type");
    const origin = decodeURIComponent(params.get("origin") || "");
    $("approve-origin").textContent = origin || "Desconhecido";
    $("approve-type").textContent = TYPE_LABELS[type] || type;
    try {
      const pending = await sendToBackground("getPendingApproval", { id: requestId });
      if (pending) {
        const pendingType = pending.type || type;
        $("approve-origin").textContent = pending.origin || "Desconhecido";
        $("approve-type").textContent = TYPE_LABELS[pendingType] || pendingType;
        const details = $("approve-details");
        if (pending.data.messageText && pendingType === "signMessage") {
          details.innerHTML = `
          <div class="approve-row">
            <span class="approve-label">Mensagem</span>
            <span class="approve-value" style="word-break:break-all;font-size:12px">${escapeHtml(pending.data.messageText)}</span>
          </div>
        `;
        }
        if (pendingType === "connect") {
          details.innerHTML = `
          <div class="approve-row">
            <span class="approve-label">Permissao</span>
            <span class="approve-value">Ver endereco publico da carteira</span>
          </div>
        `;
        }
        if (pending.data.transactionSize) {
          const analysis = pending.data.analysis || {};
          const detailLines = (analysis.details || []).slice(0, 8).map((line) =>
            `<div style="margin:4px 0;word-break:break-word">${escapeHtml(line)}</div>`
          ).join("");
          const feeText = analysis.feeSol == null ? "Indisponivel" : `${Number(analysis.feeSol).toFixed(9)} SOL`;
          const simulationText = analysis.simulation || "Nao executada";
          details.innerHTML = `
          <div class="approve-row">
            <span class="approve-label">Tamanho</span>
            <span class="approve-value">${pending.data.transactionSize} bytes</span>
          </div>
          <div class="approve-row">
            <span class="approve-label">Pagador da taxa</span>
            <span class="approve-value" style="word-break:break-all;font-size:11px">${escapeHtml(analysis.feePayer || "desconhecido")}</span>
          </div>
          <div class="approve-row">
            <span class="approve-label">Taxa estimada</span>
            <span class="approve-value">${escapeHtml(feeText)}</span>
          </div>
          <div class="approve-row">
            <span class="approve-label">Simulacao</span>
            <span class="approve-value">${escapeHtml(simulationText)}</span>
          </div>
          <div class="approve-details" style="margin-top:10px;text-align:left">${detailLines || "Programa nao identificado"}</div>
          <div class="warning-box" style="margin-top:10px;text-align:left">
            Confira os dados antes de assinar. Transacoes podem movimentar seus fundos.
          </div>
        `;
        }
      }
    } catch (e) {
      console.warn("Could not load pending details:", e);
    }
    $("btn-approve").addEventListener("click", () => {
      chrome.runtime.sendMessage({
        source: "wf-approve",
        requestId,
        approved: true
      });
      window.close();
    });
    $("btn-reject").addEventListener("click", () => {
      chrome.runtime.sendMessage({
        source: "wf-approve",
        requestId,
        approved: false
      });
      window.close();
    });
  });
  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }
})();
